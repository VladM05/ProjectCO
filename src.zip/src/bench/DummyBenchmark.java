package bench;

public class DummyBenchmark {
}
