package timing;

public class Timer {
}
