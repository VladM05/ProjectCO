package timing;

public interface ITimer {

public void start();

public void stop();

public void pause();

public void resume();

}