package logging;

public class ConsoleLogger {
}
