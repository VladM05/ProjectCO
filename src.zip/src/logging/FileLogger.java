package logging;

public class FileLogger {
}
