package logging;

public interface ILogger {

    public void write(String string);

    public write(long value);

    public void write(Object ... values);

}
