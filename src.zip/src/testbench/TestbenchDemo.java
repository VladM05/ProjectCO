package testbench;

import logging.ConsoleLogger;
import logging.TimeUnit;


public class TestbenchDemo {
  /*  ITimer timer = new Timer();
    ILog log = //new FileLogger("bench.log"); // new ConsoleLogger();
    int n = 6;
    TimeUnit timeUnit = TimeUnit.Micro;
    IBenchmark bench = new DummyBenchmark();

    bench.initialize(100000);
    timer.start();
    bench.run();
    log.write("Finished in", timer.stop(), "ns");

    log.close(); */
}
